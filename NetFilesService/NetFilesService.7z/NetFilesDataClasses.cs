namespace NetFiles.Service
{
    partial class NetFilesDataClassesDataContext
    {
    }
}